// Smooth Scroll for Internal Links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
    e.preventDefault();

    document.querySelector(this.getAttribute('href')).scrollIntoView({
      behavior: 'smooth'
    });
  });
});

// Reveal Elements on Scroll
const revealElements = document.querySelectorAll('.reveal');

const observer = new IntersectionObserver((entries, observer) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.1 });

revealElements.forEach(element => {
  observer.observe(element);
});

// Hover Effect for Buttons and Links
const buttonsAndLinks = document.querySelectorAll('a, button');

buttonsAndLinks.forEach(element => {
  element.addEventListener('mouseover', () => {
    element.style.transform = 'scale(1.05)';
    element.style.transition = 'transform 0.3s ease-in-out';
  });

  element.addEventListener('mouseout', () => {
    element.style.transform = 'scale(1)';
  });
});

// Page Load Animation
window.addEventListener('load', () => {
  const loader = document.getElementById('loader');
  loader.style.opacity = '0';
  loader.style.transition = 'opacity 0.5s ease';
  setTimeout(() => loader.style.display = 'none', 500);
});

// Back to Top Button
const backToTopButton = document.getElementById('backToTop');

window.addEventListener('scroll', () => {
  if (window.pageYOffset > 300) {
    backToTopButton.style.display = 'block';
  } else {
    backToTopButton.style.display = 'none';
  }
});

backToTopButton.addEventListener('click', () => {
  window.scrollTo({
    top: 0,
    behavior: 'smooth'
  });
});

// Existing JavaScript
const patternElement = document.getElementById("pattern");
const heroElement = document.querySelector(".hero");
const gradientElement = document.getElementById("gradient");

let mousePosition = {
  x: 0,
  y: 0
};

let isMouseInHero = false;

document.addEventListener("mousemove", (mouse) => {
  if (isMouseInHero) {
    mousePosition = {
      x: mouse.clientX,
      y: mouse.clientY
    };
  }
});

heroElement.addEventListener("mouseenter", () => {
  isMouseInHero = true;
});

heroElement.addEventListener("mouseleave", () => {
  isMouseInHero = false;
});

const loop = () => {
  if (isMouseInHero) {
    gradientElement.style.transform = `translate(${mousePosition.x}px, ${mousePosition.y}px)`;
  }
  
  // Request the next animation frame
  window.requestAnimationFrame(loop);
};

// Start the animation loop
window.requestAnimationFrame(loop);

const countY = Math.ceil(patternElement.clientHeight / 40) + 1;
const countX = Math.ceil(patternElement.clientWidth / 48) + 1;
const gap = 2;

for (let i = 0; i < countY; i++) {
  for (let j = 0; j < countX; j++) {
    const hexagon = document.createElement("div");
    hexagon.style = `
      background: url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iODciIGhlaWdodD0iMTAwIiB2aWV3Qm94PSIwIDAgODcgMTAwIiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgo8cGF0aCBkPSJNMi4xOTg3MyAyNi4xNTQ3TDQzLjUgMi4zMDk0TDg0LjgwMTMgMjYuMTU0N1Y3My44NDUzTDQzLjUgOTcuNjkwNkwyLjE5ODczIDczLjg0NTNWMjYuMTU0N1oiIGZpbGw9IiMxMzEyMTciIHN0cm9rZT0iIzEzMTIxNyIgc3Ryb2tlLXdpZHRoPSI0Ii8+Cjwvc3ZnPgo=') no-repeat;
      width: 44px;
      height: 50px;
      background-size: contain;
      position: absolute;
      top: ${i * 40}px;
      left: ${j * 48 + ((i * 24) % 48)}px;
    `;

    patternElement.appendChild(hexagon);
  }
}

// Typewriter effect
const typewriterText = document.getElementById("typewriter-text");
const text = "Labonde Lucas";
let index = 0;
let isAdding = true;

const typewriterEffect = () => {
  if (isAdding) {
    if (index < text.length) {
      typewriterText.innerHTML += text.charAt(index);
      index++;
    } else {
      isAdding = false;
      setTimeout(typewriterEffect, 1000); // Pause before deleting
      return;
    }
  } else {
    if (index > 0) {
      typewriterText.innerHTML = text.substring(0, index - 1);
      index--;
    } else {
      isAdding = true;
    }
  }
  setTimeout(typewriterEffect, isAdding ? 200 : 100);
};

typewriterEffect();
